package com.instagram.controller;

public interface InstagramControllerInterface {

	void createProfile();

	void loginProfile();

	void editProfile();

	void deleteProfile();

	void viewProfile();

}
